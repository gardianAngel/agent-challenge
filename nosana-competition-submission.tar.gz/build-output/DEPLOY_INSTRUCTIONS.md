# Nosana Competition Deployment Instructions

## Quick Deploy (Recommended)

1. **Upload this entire build-output directory to your competition repository**

2. **Build with Docker when available:**
   ```bash
   docker build -f Dockerfile-optimized -t YOUR_USERNAME/defi-risk-oracle .
   docker push YOUR_USERNAME/defi-risk-oracle:latest
   ```

3. **Deploy to Nosana:**
   ```bash
   nosana deploy --image YOUR_USERNAME/defi-risk-oracle:latest --public
   ```

## Direct Deploy (No Docker)

1. **Run directly:**
   ```bash
   node start.js
   ```

2. **Health check:**
   ```bash
   curl http://localhost:3000/health
   ```

## What's Included

- ✅ Complete working application (start.js)
- ✅ All 6 Mastra agents (agents/ directory)
- ✅ Nosana tools integration (tools/ directory)
- ✅ Optimized Docker configuration
- ✅ Production package.json
- ✅ Health monitoring endpoint

## Competition Features

- **Multi-Agent System**: 6 specialized DeFi risk agents
- **Real-time Monitoring**: Live protocol assessment
- **WebSocket Updates**: Real-time data streaming
- **Production Ready**: Complete Docker containerization
- **Health Checks**: Built-in system verification

Your submission is COMPETITION READY! 🏆
